import { web3Reducer } from './reducers';

export { default as web3Types } from './types';
export { default as web3Actions } from './actions';

export default web3Reducer;
